import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import MessageBubble from './MessageBubble';
import './styles.css';

const MODELS = {
  'Emotion Detection': 'bhadresh-savani/distilbert-base-uncased-emotion',
  'Sentiment Analysis': 'distilbert-base-uncased-finetuned-sst-2-english',
  'Toxicity Detection': 'unitary/toxic-bert',
};

function App() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [selectedModel, setSelectedModel] = useState(MODELS['Emotion Detection']);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
  
    const userMessage = { text: input, sender: 'user' };
    setMessages((prev) => [...prev, userMessage]);
  
    try {
      const response = await axios.post(
        `https://api-inference.huggingface.co/models/${selectedModel}`,
        { inputs: input },
        {
          headers: {
            Authorization: 'Bearer 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',
          },
        }
      );
  
      const label = Array.isArray(response.data[0])
        ? response.data[0][0].label
        : response.data[0].label || response.data[0][0]?.label;
  
      const customResponse = getCustomResponse(label, selectedModel, input);
  
      const botMessage = {
        text: customResponse,
        sender: 'bot',
      };
  
      setMessages((prev) => [...prev, botMessage]);
    } catch (err) {
      console.error(err.response?.data || err.message);
      setMessages((prev) => [
        ...prev,
        {
          text: 'Sorry, something went wrong. Please try again.',
          sender: 'bot',
        },
      ]);
    }
    setInput('');
  };
  

  // const handleSend = async () => {
  //   if (!input.trim()) return;

  //   const userMessage = { text: input, sender: 'user' };
  //   setMessages((prev) => [...prev, userMessage]);

  //   try {
  //     const response = await axios.post(
  //       `https://api-inference.huggingface.co/models/${selectedModel}`,
  //       { inputs: input },
  //       {
  //         headers: {
  //           Authorization: 'Bearer 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',
  //         },
  //       }
  //     );

  //     const label = Array.isArray(response.data[0])
  //       ? response.data[0][0].label // models like sentiment return [{label, score}]
  //       : response.data[0].label || response.data[0][0]?.label; // fallback

  //     const botMessage = {
  //       text: `Model: *${getModelName(selectedModel)}* predicts: **${label}**.`,
  //       sender: 'bot',
  //     };

  //     setMessages((prev) => [...prev, botMessage]);
  //   } catch (err) {
  //     setMessages((prev) => [
  //       ...prev,
  //       { text: 'Oops! Something went wrong with the model.', sender: 'bot' },
  //     ]);
  //     console.error(err.response?.data || err.message);
  //   }

  //   setInput('');
  // };

  const getModelName = (modelId) => {
    return Object.keys(MODELS).find((key) => MODELS[key] === modelId) || 'Model';
  };

  return (
    <div className="chat-window">
      <h1 className="chat-title">🧘 Mental Health Assistant</h1>

      <div style={{ textAlign: 'center', marginBottom: '1rem' }}>
        <label htmlFor="model-select"><strong>Choose Model:</strong> </label>
        <select
          id="model-select"
          value={selectedModel}
          onChange={(e) => {
            setSelectedModel(e.target.value);
            setMessages([]);
          }}
        >
          {Object.entries(MODELS).map(([name, id]) => (
            <option key={id} value={id}>{name}</option>
          ))}
        </select>
      </div>

      <div className="messages">
        {messages.map((msg, idx) => (
          <MessageBubble key={idx} text={msg.text} sender={msg.sender} />
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="input-box">
        <input
          placeholder="Type your thoughts here..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
        />
        <button onClick={handleSend}>Send</button>
      </div>
    </div>
  );
}

export default App;

function getCustomResponse(label, modelId, inputText) {
  if (modelId.includes('emotion')) {
    const emotionResponses = {
      sadness: "It sounds like you're feeling down. I'm here to listen if you want to share more.",
      joy: "That’s wonderful! 😊 What made you feel this way?",
      anger: "It’s okay to feel angry. Want to talk about what’s been frustrating you?",
      fear: "That sounds scary. You're not alone — I'm here with you.",
      surprise: "Wow, that sounds unexpected. Want to tell me more?",
      love: "That's beautiful 💖 Tell me more about what or who made you feel this.",
    };
    return emotionResponses[label.toLowerCase()] || "I'm here to listen to whatever you're feeling.";
  }

  if (modelId.includes('sentiment')) {
    return label === 'POSITIVE'
      ? "That's great to hear! 😊 Keep the good vibes coming."
      : "I'm sorry to hear that. Want to talk more about what's going on?";
  }

  if (modelId.includes('toxic')) {
    const toxicLabel = label.toUpperCase(); // ensure case consistency

    if (toxicLabel === 'TOXIC' || toxicLabel === 'LABEL_1') {
      return "⚠️ That sounds a bit harsh. Let's try to reframe it together — I'm here to help, not judge.";
    } else {
      return "Thanks for keeping the conversation respectful 🙏";
    }
  }

  return `Based on the input, the model detected: ${label}`;
}
