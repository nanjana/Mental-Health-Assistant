import React from 'react';

function MessageBubble({ text, sender }) {
  const isUser = sender === 'user';
  return (
    <div className={`message ${isUser ? 'user' : 'bot'}`}>
      <p>{text}</p>
    </div>
  );
}

export default MessageBubble;